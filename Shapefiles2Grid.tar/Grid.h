#pragma once
#include "ShapeFile.h"
#include <vector>
#include "gdal_priv.h"
#include "Utils.h"
class Grid
{
public:
	Grid();
	Grid(const OGREnvelope& bb, const double& gridcellsize, int expandByCells = 1);
	void fromFishnetShape(std::string fishnetfile);
	void fromFishnetRaster(std::string fishnetfile, bool load = false);
	~Grid();
	int getNumberOfValidCells();
	void reset(std::string attributeName = "ca11");
	void reset(std::vector<std::string> dimensions);
	static Grid* createFishnet(const std::string& shapefile, double gridcellsize);
	OGRPolygon* toOGRPolygon(OGRLayer* layer, const OGREnvelope& bb);
	void normalizedByArea();
	void toShape(ShapeFile* copyfrom, const std::string& outputfile, bool writeAttribute = false);
	void toShape(ShapeFile* copyfrom, const std::string& outputfile, int cellID);
	void toRaster(std::string filename);
	Grid* upscale(int scale);
	void gatherCells(ShapeFile* input, const char* attributeID = "ca11");
	//void gatherCells(const std::string& inputfile);
private:
	double calFraction(OGRFeature* fea, const int& footprintIdx);
public:
	double* cells;
	OGREnvelope bound;
	int nrows;
	int ncols;
	int slice;
	double _adfGeoTransform[6];
	std::vector<std::string> dims;
};

