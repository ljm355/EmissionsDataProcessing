// PolygonStatistics.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ogrsf_frmts.h"
#include "gdal_priv.h"
#include <QFileinfo>
#include <map>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>      // std::setprecision
#include <qdir.h>
#include "qfileinfo.h"
#include "DbfFile.h"
#include "ShapeFile.h"
#include "BoundManager.h"
#include "Grid.h"
#include "Utils.h"
#include "Preprocessor.h"
#include "ShapeCreator.h"
#include "ScaleByFuel.h"
#include "NonPointProcessor.h"
void verifyRailRoad()
{

	double* sums = new double[1000000];
	memset(sums, 0, sizeof(double) * 1000000);

	ShapeFile rail1("B:/Baltimore/gridPrep_SHP_master/WGS84/OnRoad.shp");
	ShapeFile rail2("B:/Baltimore/gridPrep_SHP_master/WGS84/result/OnRoad.shp");

	OGRFeature *poFeature;
	rail2.poLayer->ResetReading();
	int id = 0;
	while ((poFeature = rail2.poLayer->GetNextFeature()) != NULL)
	{
		//int id = poFeature->GetFieldAsInteger("FID_OnRoad");
		//printf("%d\n", id);
		//sums[id] = sums[id] + poFeature->GetFieldAsDouble("ca");
		OGRFeature::DestroyFeature(poFeature);
	}


	rail1.poLayer->ResetReading();
	id = 0;
	while ((poFeature = rail1.poLayer->GetNextFeature()) != NULL)
	{
		double sum = poFeature->GetFieldAsDouble("ca");
		if (abs(sums[id] - sum) > 0.001)
		{
			printf("%d,%.5f,%.5f\n", id, sum, sums[id]);
		}
		id++;
		OGRFeature::DestroyFeature(poFeature);
	}


	//"FID_Railro"
}

void sum(std::string dir)
{


	std::vector<std::string> files;

	QDir input_dir(dir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	std::string indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		if (fileInfo.fileName().endsWith("fishnet.shp"))
			continue;


		files.push_back(fileInfo.fileName().toLocal8Bit().data());
	}

	double sum = 0;

	for (size_t i = 0; i < files.size(); i++)
	{
		double subtotal = 0;
		ShapeFile shp(indir + files[i]);
		OGRFeature *poFeature;
		shp.poLayer->ResetReading();
		int idx = shp.poLayer->GetLayerDefn()->GetFieldIndex("ca");
		while ((poFeature = shp.poLayer->GetNextFeature()) != NULL)
		{
			sum += poFeature->GetFieldAsDouble(idx);
			subtotal += poFeature->GetFieldAsDouble(idx);
			OGRFeature::DestroyFeature(poFeature);
		}
		printf("sector %s: %.5f\n", files[i].data(), subtotal / 1000000 / 1000);
	}



	printf("%.5f\n", sum);
	printf("%.5f\n", sum / 1000000 / 1000);

	getchar();

}
//typedef enum
//{
//	wkbUnknown = 0,         /**< unknown type, non-standard */
//	wkbPoint = 1,           /**< 0-dimensional geometric object, standard WKB */
//	wkbLineString = 2,      /**< 1-dimensional geometric object with linear
//							*   interpolation between Points, standard WKB */
//	wkbPolygon = 3,         /**< planar 2-dimensional geometric object defined
//							*   by 1 exterior boundary and 0 or more interior
//							*   boundaries, standard WKB */
//	wkbMultiPoint = 4,      /**< GeometryCollection of Points, standard WKB */
//	wkbMultiLineString = 5, /**< GeometryCollection of LineStrings, standard WKB */
//	wkbMultiPolygon = 6,    /**< GeometryCollection of Polygons, standard WKB */
//	wkbGeometryCollection = 7, /**< geometric object that is a collection of 1
//							   or more geometric objects, standard WKB */
//	wkbNone = 100,          /**< non-standard, for pure attribute records */
//	wkbLinearRing = 101,    /**< non-standard, just for createGeometry() */
//	wkbPoint25D = 0x80000001, /**< 2.5D extension as per 99-402 */
//	wkbLineString25D = 0x80000002, /**< 2.5D extension as per 99-402 */
//	wkbPolygon25D = 0x80000003, /**< 2.5D extension as per 99-402 */
//	wkbMultiPoint25D = 0x80000004, /**< 2.5D extension as per 99-402 */
//	wkbMultiLineString25D = 0x80000005, /**< 2.5D extension as per 99-402 */
//	wkbMultiPolygon25D = 0x80000006, /**< 2.5D extension as per 99-402 */
//	wkbGeometryCollection25D = 0x80000007 /**< 2.5D extension as per 99-402 */
//} OGRwkbGeometryType;
void updateFieldAfterIntersection(std::string filename)
{
	ShapeFile input(filename, 1);
	OGRFeature *poFeature;
	input.poLayer->ResetReading();
	std::vector<int> fields;

	for (size_t i = 0; i < input.poLayer->GetLayerDefn()->GetFieldCount(); i++)
	{
		OGRFieldDefn* field = input.poLayer->GetLayerDefn()->GetFieldDefn(i);
		std::string fieldname = field->GetNameRef();
		if (fieldname.size() > 1 && QString(field->GetNameRef()).toLower().indexOf("ca") > -1)
			fields.push_back(input.poLayer->GetLayerDefn()->GetFieldIndex(fieldname.data()));
	}

	int idIndex = input.poLayer->GetLayerDefn()->GetFieldIndex("Id");

	OGRwkbGeometryType gtype = input.poLayer->GetGeomType();
	int footprintIndex = -1;
	if (gtype == wkbLineString || gtype == wkbMultiLineString || gtype == wkbLineString25D)
	{
		footprintIndex = input.poLayer->GetLayerDefn()->GetFieldIndex("length");
	}
	else if (gtype == wkbPolygon || gtype == wkbPolygon25D || gtype == wkbMultiPolygon)
	{
		footprintIndex = input.poLayer->GetLayerDefn()->GetFieldIndex("area");
	}
	else
	{
		return;
	}
	while ((poFeature = input.poLayer->GetNextFeature()) != NULL)
	{
		OGRGeometry* geo = poFeature->GetGeometryRef();
		OGRwkbGeometryType gtype = geo->getGeometryType();

		double footprintOld = poFeature->GetFieldAsDouble(footprintIndex);
		double footprintNew = 0;

		if (gtype == wkbLineString || gtype == wkbMultiLineString || gtype == wkbLineString25D)
		{
			footprintNew = Utils::calPolylineLength(poFeature->GetGeometryRef());
		}
		else if (gtype == wkbPolygon || gtype == wkbMultiPolygon || gtype == wkbPolygon25D)
		{
			footprintNew = Utils::calPolygonArea(poFeature->GetGeometryRef());
		}

		double fraction = 0;
		if (!isinf(footprintOld) && footprintOld > 0)
			fraction = footprintNew / footprintOld;

		for (size_t i = 0; i < fields.size(); i++)
		{
			double ca = poFeature->GetFieldAsDouble(fields[i]);
			if (gtype == wkbLineString || gtype == wkbMultiLineString || gtype == wkbLineString25D)
			{
				poFeature->SetField(fields[i], ca*fraction);
			}
			else if (gtype == wkbPolygon || gtype == wkbMultiPolygon || gtype == wkbPolygon25D)
			{
				poFeature->SetField(fields[i], ca*fraction);
			}
		}

		poFeature->SetField(footprintIndex, footprintNew);
		input.poLayer->SetFeature(poFeature);


		OGRFeature::DestroyFeature(poFeature);

	}

}
void updateFieldAfterIntersectionForDir(std::string indir)
{
	std::vector<std::string> files;
	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		std::string name = fileInfo.fileName().toLocal8Bit().data();
		if (isdigit(name[0]))
			continue;
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		if (fileInfo.fileName().endsWith("fishnet.shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
		std::string infile = indir + files[files.size() - 1];
		updateFieldAfterIntersection(infile);
	}
}
void intersectWithPolygonForDir(std::string boundary,std::string indir, std::string outdir)
{
	std::vector<std::string> files;
	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QDir output_dir(outdir.data());
	if (!output_dir.exists())
		output_dir.mkpath(".");
	outdir = (output_dir.absolutePath() + "/").toLocal8Bit().data();


	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		std::string name = fileInfo.fileName().toLocal8Bit().data();
		if (isdigit(name[0]))
			continue;
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		if (fileInfo.fileName().endsWith("fishnet.shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
		std::string infile = indir + files[files.size()-1];
		std::string outfile = outdir + files[files.size() - 1];
		//intersectWithArcGIS(infile, boundary, outfile);
		updateFieldAfterIntersection(outfile);
		printf("%s\n", infile.data());
	}



}
OGREnvelope splitIntoTiles(std::string indir, std::string outdir, OGREnvelope bound,double gridsize)
{
	QDir qoutdir(outdir.data());
	if (!qoutdir.exists())
		qoutdir.mkpath(".");
	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
	std::vector<std::string> files;

	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		std::string name = fileInfo.fileName().toLocal8Bit().data();
		if (isdigit(name[0]))
			continue;
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
		std::string infile = indir + files[files.size() - 1];
		//updateFootprint(infile);
	}
	std::string fishnetfile = outdir + "fishnet.shp";
	ShapeFile spatialRefFile(indir + files[0]);
	if (!spatialRefFile.poLayer->GetSpatialRef()->IsGeographic())
	{
		//FOOTPRINT_SCALE_FACTOR = 1;
	}
	else
	{
		//FOOTPRINT_SCALE_FACTOR = getDegreeToMeter(spatialRefFile.poLayer);
		gridsize = gridsize / Utils::getDegreeToMeter(spatialRefFile.poLayer);
	}
	Grid grid(bound, gridsize, 1);
   //if(!QFileInfo(fishnetfile.data()).exists())
	 grid.toShape(&spatialRefFile, fishnetfile, false);
	for (int n = 0; n < grid.nrows*grid.ncols; n++)
	{
		std::stringstream subboundss;
		subboundss << outdir << n << ".shp";
		//if (QFileInfo(subboundss.str().data()).exists())
		//	continue;
		if (!QFileInfo(subboundss.str().data()).exists())
		    grid.toShape(&spatialRefFile, subboundss.str().data(), n);
		std::stringstream subdirss;
		subdirss << outdir << n;
		QDir qsubdir(subdirss.str().data());
		if (!qsubdir.exists())
			qsubdir.mkpath(".");
		else
			continue;
		std::string subdir = (qsubdir.absolutePath() + "/").toLocal8Bit().data();

		for (int i = 0; i < files.size(); i++)
		{

			std::string outputfile = subdir + files[i];
			std::string tagfile = outputfile + ".locked";

			if (QFileInfo(outputfile.data()).exists() || QFileInfo(tagfile.data()).exists())
				continue;
	
			std::ofstream ofs(tagfile.data());
			ofs.close();
			printf("%s\n", outputfile.data());
		
			Preprocessor::clipWithArcGIS(indir + files[i], subboundss.str().data(), outputfile);
			updateFieldAfterIntersection(outputfile);
			if (QFileInfo(tagfile.data()).exists())
				QFile::remove(tagfile.data());
		}
		 
		//for (int i = 0; i < files.size(); i++)
		//{

		//	std::string outputfile = subdir + files[i];
		//	std::string tagfile = outputfile + ".locked";

		//	if (QFileInfo(outputfile.data()).exists() || QFileInfo(tagfile.data()).exists())
		//		continue;

		//	std::ofstream ofs(tagfile.data());
		//	ofs.close();
		//	printf("%s\n", outputfile.data());
		//	clipWithArcGIS(indir + files[i], subboundss.str().data(), outputfile);
		//	if (QFileInfo(tagfile.data()).exists())
		//		QFile::remove(tagfile.data());
		//}


	}
	return grid.bound;
}
OGREnvelope intersectByTiles(std::string indir, std::string outdir, OGREnvelope bound, double gridsize, double tilegridsize)
{
	QDir qoutdir(outdir.data());
	if (!qoutdir.exists())
		qoutdir.mkpath(".");
	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
	std::vector<std::string> files;

	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string name = fileInfo.fileName().toLocal8Bit().data();
		if (isdigit(name[0]))
			continue;
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
	}
	std::string fishnetfile = outdir + "fishnet.shp";
	ShapeFile spatialRefFile(indir + files[0]);
	if (!spatialRefFile.poLayer->GetSpatialRef()->IsGeographic())
	{
		//FOOTPRINT_SCALE_FACTOR = 1;
	}
	else
	{
		//FOOTPRINT_SCALE_FACTOR = getDegreeToMeter(spatialRefFile.poLayer);
		gridsize = gridsize / Utils::getDegreeToMeter(spatialRefFile.poLayer);
	}
	Grid grid(bound, gridsize, 1);
	//if (!QFileInfo(fishnetfile.data()).exists())
	//	grid.toShape(&spatialRefFile, fishnetfile, false);
	for (int n = 0; n < grid.nrows*grid.ncols; n++)
	{
		std::stringstream subboundss;
		subboundss << outdir << n << ".shp";
		//if (QFileInfo(subboundss.str().data()).exists())
		//	continue;
		//if (!QFileInfo(subboundss.str().data()).exists())
		//	grid.toShape(&spatialRefFile, subboundss.str().data(), n);

		OGREnvelope tilebound = BoundManager::readBoundFromShape(subboundss.str());

		std::stringstream subdirss;
		subdirss << outdir << n;
		QDir qsubdir(subdirss.str().data());
		//if (!qsubdir.exists())
		//	qsubdir.mkpath(".");
		std::string subdir = (qsubdir.absolutePath() + "/").toLocal8Bit().data();


		std::stringstream subdirssout;
		subdirssout << outdir << n << "/" << tilegridsize <<  "m/";
		QDir qsubdirout(subdirssout.str().data());
		if (!qsubdirout.exists())
			qsubdirout.mkpath(".");
		else
			continue;
		std::string subdirout = (qsubdirout.absolutePath() + "/").toLocal8Bit().data();
		ShapeFile tilespatialRefFile(subboundss.str());
		Grid tilegrid(tilebound, tilegridsize, 0);
		std::string tilefishnetfile = subdirout + "fishnet.shp";
		if (!QFileInfo(tilefishnetfile.data()).exists())
			tilegrid.toShape(&tilespatialRefFile, tilefishnetfile.data());
		for (int i = 0; i < files.size(); i++)
		{

			std::string inputfile = subdir + files[i];
			std::string outputfile = subdirout + files[i];

			//std::string tagfile = outputfile + ".locked";

			//if (QFileInfo(outputfile.data()).exists() || QFileInfo(tagfile.data()).exists())
				//continue;

			//std::ofstream ofs(tagfile.data());
			//ofs.close();
			printf("%s\n", outputfile.data());
			//clipWithArcGIS(indir + files[i], subboundss.str().data(), outputfile);
			Preprocessor::intersectWithArcGIS(tilefishnetfile, inputfile, outputfile);
			//if (QFileInfo(tagfile.data()).exists())
				//QFile::remove(tagfile.data());


		}
		QFile::remove(tilefishnetfile.data());
	}
	return grid.bound;
}
void gridFolder(std::string indir, std::string outdir, double gridsize, bool skipNonRoad = false)
{
	QDir qoutdir(outdir.data());
	if (!qoutdir.exists())
		qoutdir.mkpath(".");
	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
	std::vector<std::string> files;

	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		if (!fileInfo.fileName().endsWith(".shp") || fileInfo.fileName().endsWith("fishnet.shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
	}

	std::string nonroadfile = indir + "NonRoad.shp";
	std::string fishnetfile = outdir + "fishnet.shp";
	std::string rasterfile = outdir + "fishnet.tif";


	ShapeFile boundfile(nonroadfile.data());
	if (!boundfile.poLayer->GetSpatialRef()->IsGeographic())
	{
		//FOOTPRINT_SCALE_FACTOR = 1;
	}
	else
	{
		//FOOTPRINT_SCALE_FACTOR = getDegreeToMeter(boundfile.poLayer);
		gridsize = gridsize / Utils::getDegreeToMeter(boundfile.poLayer);
	}


	Grid* fishnet = Grid::createFishnet(nonroadfile, gridsize);
	fishnet->reset();
	fishnet->toShape(&boundfile, fishnetfile, false);

	for (size_t i = 0; i < files.size(); i++)
	{
		if (skipNonRoad && files[i] == "NonRoad.shp")
			continue;
		printf("%s\n", (outdir + files[i]).data());
		//intersectWithFishnet(fishnet, fishnetfile, indir + files[i], outdir + files[i]);
		if (!QFileInfo((outdir + files[i]).data()).exists())
		{
			Preprocessor::intersectWithArcGIS(fishnetfile, indir + files[i], outdir + files[i]);
			updateFieldAfterIntersection(outdir + files[i]);
		}

		ShapeFile input((outdir + files[i]).data());
		fishnet->gatherCells(&input);
	}

	fishnet->toShape(&boundfile, fishnetfile, true);
	fishnet->toRaster(rasterfile);
	boundfile.close();

	//for (size_t i = 0; i < files.size(); i++)
	//{
	//	if (skipNonRoad && files[i] == "NonRoad.shp")
	//		continue;
	//	ShapeFile input((outdir + files[i]).data());
	//	if (input.poLayer->GetGeomType() == wkbPoint || input.poLayer->GetGeomType() == wkbMultiPoint || input.poLayer->GetGeomType() == wkbPoint25D)
	//		continue;
	//	std::string sectorfile = files[i].substr(0, files[i].length() - 4);
	//	std::string sectorfileout = outdir + sectorfile + ".tif";
	//	printf("%s\n", sectorfile.data());
	//	fishnet->reset();
	//	gatherCells(fishnet, &input);
	//	fishnet->toRaster(sectorfileout);

	//	sectorfileout = outdir + sectorfile + "2.shp";
	//	fishnet->toShape(&input, sectorfileout,true);

	//}

	delete fishnet;
}

//void gridShapeFile(std::string infile, std::string outfile, std::string fishnetfile)
//{
//
//	std::string tmpefile = (QFileInfo(outfile.data()).dir().absolutePath() + "/" +  QFileInfo(outfile.data()).baseName() + "_2.shp").toLocal8Bit().data();
//	std::string outfiletif = (QFileInfo(outfile.data()).dir().absolutePath() + "/" + QFileInfo(outfile.data()).baseName() + ".tif").toLocal8Bit().data();
//	Utils::updateFootprint(infile);
//	Preprocessor::intersectWithArcGIS(fishnetfile, infile, tmpefile);
//	//updateFieldAfterIntersection(tmpefile);
//	ShapeFile input(tmpefile);
//	Grid fishnet;
//	fishnet.fromFishnetShape(fishnetfile);
//
//	fishnet.gatherCells(&input,"C11");
//	fishnet.toShape(&input, outfile, true);
//	fishnet.toRaster(outfiletif);
//	const char *pszDriverName = "ESRI Shapefile";
//	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(
//		pszDriverName);
//	poDriver->DeleteDataSource(tmpefile.data());
//}
//void gridShapeFile(std::string infile, std::string outfile, double gridsize)
//{
//	OGREnvelope bound = BoundManager::readBoundFromShape(infile.data());
//	Grid fishnet(bound, gridsize, 0);
//	fishnet.reset();
//	ShapeFile input(infile);
//	std::string tmpefishnetfile = (QFileInfo(outfile.data()).baseName() + "_1.shp").toLocal8Bit().data();
//	std::string tmpefile = (QFileInfo(outfile.data()).baseName() + "_2.shp").toLocal8Bit().data();
//	fishnet.toShape(&input, tmpefishnetfile, false);
//	Preprocessor::intersectWithArcGIS(tmpefishnetfile, infile, tmpefile);
//	input.close();
//	input = ShapeFile(tmpefile);
//	fishnet.gatherCells(&input);
//	fishnet.toShape(&input, outfile, true);
//	const char *pszDriverName = "ESRI Shapefile";
//	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(
//		pszDriverName);
//	poDriver->DeleteDataSource(tmpefishnetfile.data());
//	poDriver->DeleteDataSource(tmpefile.data());
//}


void gridFolderForSectors(std::string indir, std::string outdir, double gridsize, bool skipNonRoad = false)
{
	QDir qoutdir(outdir.data());
	if (!qoutdir.exists())
		qoutdir.mkpath(".");
	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
	std::vector<std::string> files;

	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		if (!fileInfo.fileName().endsWith(".shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
	}

	std::string nonroadfile = indir + "NonRoad.shp";
	std::string fishnetfile = outdir + "fishnet.shp";
	std::string rasterfile = outdir + "fishnet.tif";

	ShapeFile boundfile(nonroadfile.data());
	if (!boundfile.poLayer->GetSpatialRef()->IsGeographic())
	{
		//FOOTPRINT_SCALE_FACTOR = 1;
	}
	else
	{
		//FOOTPRINT_SCALE_FACTOR = getDegreeToMeter(boundfile.poLayer);
		gridsize = gridsize / Utils::getDegreeToMeter(boundfile.poLayer);
	}


	Grid* fishnet = Grid::createFishnet(nonroadfile, gridsize);
	fishnet->reset();
	//fishnet->toShape(&boundfile, fishnetfile, false);

	for (size_t i = 0; i < files.size(); i++)
	{
		if (skipNonRoad && files[i] == "NonRoad.shp")
			continue;
		printf("%s\n", (outdir + files[i]).data());
		Preprocessor::intersectWithFishnet(fishnet, fishnetfile, indir + files[i], outdir + files[i]);
	}

	//fishnet->toShape(&boundfile, fishnetfile, true);
	//fishnet->toRaster(rasterfile);
	boundfile.close();

	for (size_t i = 0; i < files.size(); i++)
	{
		if (skipNonRoad && files[i] == "NonRoad.shp")
			continue;

		ShapeFile input((outdir + files[i]).data());
		if (input.poLayer->GetGeomType() == wkbPoint || input.poLayer->GetGeomType() == wkbMultiPoint || input.poLayer->GetGeomType() == wkbPoint25D)
			continue;
		std::string sectorfile = files[i].substr(0, files[i].length() - 4);
		sectorfile = outdir + sectorfile + ".tif";
		printf("%s\n", sectorfile.data());
		fishnet->reset();
		fishnet->gatherCells(&input);
		fishnet->toRaster(sectorfile);
	}

	delete fishnet;
}
//OGRErr OGRLayer::SetIgnoredFields(const char ** 	papszFields)
//virtual
//Set which fields can be omitted when retrieving features from the layer.
//
//If the driver supports this functionality(testable using OLCIgnoreFields capability), it will not fetch the specified fields in subsequent calls to GetFeature() / GetNextFeature() and thus save some processing time and / or bandwidth.
//
//Besides field names of the layers, the following special fields can be passed : "OGR_GEOMETRY" to ignore geometry and "OGR_STYLE" to ignore layer style.
//
//By default, no fields are ignored.
//
//This method is the same as the C function OGR_L_SetIgnoredFields()
//
//Parameters
//papszFields	an array of field names terminated by NULL item.If NULL is passed, the ignored list is cleared.
//Returns
//OGRERR_NONE if all field names have been resolved(even if the driver does not support this method)
//Reimplemented in GNMGenericLayer, OGRProxiedLayer, OGRUnionLayer, OGRMutexedLayer, and OGRLayerDecorator.

std::vector<std::string> loadAllSectorFile(std::string indir)
{
	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	std::vector<std::string> files;

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		if (!fileInfo.fileName().endsWith(".shp") || fileInfo.fileName().toLower().endsWith("fishnet.shp"))
			continue;

		files.push_back(indir + fileInfo.fileName().toLocal8Bit().data());
	}
	return files;
}

//std::vector<std::string> findChildDirctories(std::string outdir, OGREnvelope bound, double gridsize, std::string resolution)
//{
//	QDir qoutdir(outdir.data());
//	if (!qoutdir.exists())
//		qoutdir.mkpath(".");
//	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();
//	std::vector<std::string> dirs;
//	Grid grid(bound, gridsize, 1);
//	for (int n = 0; n < grid.nrows*grid.ncols; n++)
//	{
//		std::stringstream subdirss;
//		subdirss << outdir << n;
//		OGREnvelope bound = BoundManager::readBoundFromShape(subdirss.str() + ".shp");
//
//		subdirss << "/" << resolution;
//		Utils::updateFishnet(subdirss.str().data(), bound, 32.8084);
//
//		dirs.push_back(subdirss.str().data());
//	}
//	return dirs;
//}

void processFolderForGrids(std::string indir, std::string outdir, std::string gridoutdir, double gridsize)
{
	QDir qoutdir(outdir.data());
	if (!qoutdir.exists())
		qoutdir.mkpath(".");
	outdir = (qoutdir.absolutePath() + "/").toLocal8Bit().data();


	QDir qgridoutdir(gridoutdir.data());
	if (!qgridoutdir.exists())
		qgridoutdir.mkpath(".");
	gridoutdir = (qgridoutdir.absolutePath() + "/").toLocal8Bit().data();

	std::vector<std::string> files;
	QDir input_dir(indir.data());
	input_dir.setFilter(QDir::Files | QDir::Hidden | QDir::NoSymLinks | QDir::NoDotAndDotDot);
	input_dir.setSorting(QDir::Name);
	indir = (input_dir.absolutePath() + "/").toLocal8Bit().data();

	QFileInfoList list = input_dir.entryInfoList();
	for (int i = 0; i < list.size(); ++i) {
		QFileInfo fileInfo = list.at(i);
		std::string input_file = (input_dir.absolutePath() + "/" + fileInfo.fileName()).toLocal8Bit().data();
		if (!fileInfo.fileName().endsWith(".shp") || fileInfo.fileName().endsWith("fishnet.shp"))
			continue;
		files.push_back(fileInfo.fileName().toLocal8Bit().data());
	}

	std::string nonroadfile = indir + "NonRoad.shp";
	std::string fishnetfile = outdir + "fishnet.shp";
	std::string rasterfile = outdir + "fishnet.tif";

	ShapeFile boundfile(nonroadfile.data());
	if (!boundfile.poLayer->GetSpatialRef()->IsGeographic())
	{
		//FOOTPRINT_SCALE_FACTOR = 1;
	}
	else
	{
		//FOOTPRINT_SCALE_FACTOR = getDegreeToMeter(boundfile.poLayer);
		gridsize = gridsize / Utils::getDegreeToMeter(boundfile.poLayer);
	}

	Grid* fishnet = Grid::createFishnet(nonroadfile, gridsize);

	/*fishnet->toShape(&boundfile, fishnetfile, false);

	for (size_t i = 0; i < files.size(); i++)
	{

	printf("%s\n", (outdir + files[i]).data());
	intersectWithArcGIS(fishnetfile, indir + files[i], outdir + files[i]);
	updateFieldAfterIntersection(outdir + files[i]);
	ShapeFile input((outdir + files[i]).data());
	gatherCells(fishnet, &input);
	}

	fishnet->toShape(&boundfile, fishnetfile, true);
	fishnet->toRaster(rasterfile);*/


	
	fishnet->reset();
	for (size_t i = 0; i < files.size(); i++)
	{
		ShapeFile input((outdir + files[i]).data());
		if (input.poLayer->GetGeomType() == wkbPoint || input.poLayer->GetGeomType() == wkbMultiPoint || input.poLayer->GetGeomType() == wkbPoint25D)
			continue;
		std::string sectorfile = files[i].substr(0, files[i].length() - 4);
		std::string sectorfileout = gridoutdir + sectorfile + ".tif";
		printf("%s\n", sectorfile.data());
		fishnet->gatherCells(&input);

	}
	fishnet->normalizedByArea();
	fishnet->toRaster(gridoutdir + "AllSectors.tif");
	fishnet->toShape(&boundfile,gridoutdir + "AllSectors.shp",true);

	for (size_t i = 0; i < files.size(); i++)
	{
		ShapeFile input((outdir + files[i]).data());
		if (input.poLayer->GetGeomType() == wkbPoint || input.poLayer->GetGeomType() == wkbMultiPoint || input.poLayer->GetGeomType() == wkbPoint25D)
			continue;
		std::string sectorfile = files[i].substr(0, files[i].length() - 4);
		std::string sectorfileout = gridoutdir + sectorfile + ".tif";
		printf("%s\n", sectorfile.data());
		fishnet->reset();
		fishnet->gatherCells(&input);
		fishnet->toRaster(sectorfileout);
		fishnet->normalizedByArea();
		sectorfileout = gridoutdir + sectorfile + ".shp";
		fishnet->toShape(&input, sectorfileout, true);
	}
	
	fishnet->reset();
	for (size_t i = 0; i < files.size(); i++)
	{
		ShapeFile input((outdir + files[i]).data());
		if (input.poLayer->GetGeomType() == wkbPoint || input.poLayer->GetGeomType() == wkbMultiPoint || input.poLayer->GetGeomType() == wkbPoint25D)
			continue;
		std::string sectorfile = files[i].substr(0, files[i].length() - 4);
		if (!QString(sectorfile.data()).contains("NonPoint"))
			continue;
		fishnet->gatherCells(&input);

	}
	fishnet->normalizedByArea();
	fishnet->toRaster(gridoutdir + "NonPoint.tif");
	fishnet->toShape(&boundfile, gridoutdir + "NonPoint.shp", true);
	boundfile.close();
	
	delete fishnet;
}

std::string double2string(double d)
{
	std::stringstream ss;
	ss << (long)d;
	return ss.str();
}

void createBySector(std::string filename, std::string dir,int fips)
{
	struct PointRecord
	{
		/*2 IND
			3 COM
			6 NonRoad
			7 Railroad
			9 Airport*/
		std::string scc;
		double ca;
		std::string facilityid;
		std::string name;
		int sector;
		double lon;
		double lat;
		int FIPS;
		PointRecord(OGRFeature* fea)
		{
			//name	lat	lon	scc	facilityid	source	sector	ca
			scc = double2string(fea->GetFieldAsDouble("scc"));

			OGRPoint*  p = (OGRPoint*)fea->GetGeometryRef();
			lon = p->getX();
			lat = p->getY();
			ca = fea->GetFieldAsDouble("SR_CO2_tC");
			
			facilityid = double2string(fea->GetFieldAsDouble("facility_i"));
			
			sector = (int)fea->GetFieldAsDouble("Sector_ID");
			FIPS = (int)fea->GetFieldAsDouble("FIPS");

			name = fea->GetFieldAsString("facility_n");
			
		}

		void setFields(OGRFeature* poFeature)
		{
			poFeature->SetField("name", name.data());
			poFeature->SetField("scc", scc.data());
			poFeature->SetField("ca", ca);
			poFeature->SetField("facilityid", facilityid.data());

			OGRPoint pt;
			pt.setX(lon);
			pt.setY(lat);
			poFeature->SetGeometry(&pt);
		}

	};
	QFileInfo fileInfo(filename.data());
	std::vector<ShapeFileBySector> shpBySectors;


	//std::string dir = "Z:/Hestia_Baltimore/gridPrep_SHP_master/";
	ShapeFile IndPoint;
	IndPoint.create((dir + "IndPoint.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	shpBySectors.push_back(ShapeFileBySector(&IndPoint, "IND",2));

	ShapeFile ComPoint;
	ComPoint.create((dir + "ComPoint.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	shpBySectors.push_back(ShapeFileBySector(&ComPoint, "COM",3));

	ShapeFile NonRoadPoint;
	NonRoadPoint.create((dir + "NonRoadPoint.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	shpBySectors.push_back(ShapeFileBySector(&NonRoadPoint, "NonRoad",6));

	ShapeFile RailroadPoint;
	RailroadPoint.create((dir + "RailroadPoint.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	shpBySectors.push_back(ShapeFileBySector(&RailroadPoint, "RAIL",7));

	ShapeFile Airport;
	Airport.create((dir + "Airport.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	shpBySectors.push_back(ShapeFileBySector(&Airport, "AIR", 9));



	for (size_t i = 0; i < shpBySectors.size(); i++)
	{
		OGRFieldDefn fieldname("name", OGRFieldType::OFTString);
		OGRFieldDefn fieldscc("scc", OGRFieldType::OFTString);
		OGRFieldDefn fieldfacilityid("facilityid", OGRFieldType::OFTString);
		OGRFieldDefn fieldca("ca", OGRFieldType::OFTReal);
		shpBySectors[i].SHP->poLayer->CreateField(&fieldname);
		shpBySectors[i].SHP->poLayer->CreateField(&fieldfacilityid);
		shpBySectors[i].SHP->poLayer->CreateField(&fieldscc);
		shpBySectors[i].SHP->poLayer->CreateField(&fieldca);

		
	}

	ShapeFile shpscc(filename);
	OGRFeature *poFeature;
	shpscc.poLayer->ResetReading();

	while ((poFeature = shpscc.poLayer->GetNextFeature()) != NULL)
	{
		PointRecord record(poFeature);
		if (record.FIPS != fips)
		{
			OGRFeature::DestroyFeature(poFeature);
			continue;
		}
		for (size_t i = 0; i < shpBySectors.size(); i++)
		{
			ShapeFileBySector& shpBySector = shpBySectors[i];
			if (shpBySector.SecID != record.sector)
				continue;
			OGRFeature* poFeatureNew = OGRFeature::CreateFeature(shpBySector.SHP->poLayer->GetLayerDefn());
			record.setFields(poFeatureNew);
			shpBySector.SHP->poLayer->CreateFeature(poFeatureNew);
			OGRFeature::DestroyFeature(poFeatureNew);
		}

		OGRFeature::DestroyFeature(poFeature);
	}

}

void linkSCC(std::string shapefile, std::string sccFile)
{
	struct SCCRecord
	{
		std::string scc;
		double lon;
		double lat;
		double ca;
		std::string facilityid;
		SCCRecord(OGRFeature* fea)
		{
			scc = double2string(fea->GetFieldAsDouble("scc"));
			lon = fea->GetFieldAsDouble("New_LON");
			lat = fea->GetFieldAsDouble("New_LAT");
			ca = fea->GetFieldAsDouble("SR_CO2_tC");
			facilityid = double2string(fea->GetFieldAsDouble("facility_i"));
		}
	};
	std::vector<SCCRecord> records;
	ShapeFile shpscc(sccFile);
	OGRFeature *poFeature;
	shpscc.poLayer->ResetReading();
	
	std::map<std::string, std::vector<SCCRecord>> recordsmap;
	while ((poFeature = shpscc.poLayer->GetNextFeature()) != NULL)
	{
		SCCRecord record(poFeature);
		records.push_back(record);
		std::map<std::string, std::vector<SCCRecord>>::iterator iter = recordsmap.find(record.facilityid);
		if (iter == recordsmap.end())
		{
			std::vector<SCCRecord> group;
			group.push_back(record);
			recordsmap[record.facilityid] = group;
		}
		else
		{
			iter->second.push_back(record);
		}
		OGRFeature::DestroyFeature(poFeature);
	}


	ShapeFile shp(shapefile, 1);
	OGRFieldDefn field("scc", OGRFieldType::OFTString);
	shp.poLayer->CreateField(&field);
	shp.poLayer->ResetReading();
	while ((poFeature = shp.poLayer->GetNextFeature()) != NULL)
	{
		std::string id = double2string(poFeature->GetFieldAsDouble("facilityid"));
		std::map<std::string, std::vector<SCCRecord>>::iterator iter = recordsmap.find(id);
		if (iter != recordsmap.end())
		{
			std::vector<SCCRecord>& group = iter->second;
			double ca = poFeature->GetFieldAsDouble("ca11");
			bool found = false;
			for (int i = 0; i < group.size(); i++)
			{
				SCCRecord& rc = group[i];
				if ((rc.ca - ca) < 0.00001)
				{
					poFeature->SetField("scc",rc.scc.data());
		
					found = true;
				}
			}
			if (!found)
			{
				printf("%s,%f", id, ca);
			}
		}
		else
		{
			poFeature->SetField("scc", "-1");
		}
		shp.poLayer->SetFeature(poFeature);
		OGRFeature::DestroyFeature(poFeature);
	}
}


//	/*2 IND
//	3 COM
//	6 NonRoad
//	7 Railroad
//	9 Airport*/
//	int SectorID;
//	double longitude;
//	double latitude;
//	int FIPS;
//	std::string facility_name;
//	std::string scc;
//	double New_LAT;
//	double New_LON;
//	double COMNG;
//	double COMpetrol;
//	double INDNG;
//	double INDpetrol;
//	double ELE;
//	double AIR;
//	double RAIL;
//	double Nonroad;

//sector ID
//longitude	latitude
//facility_name scc New_LAT New_LON
//COM(tC / yr)	
//COM NG	
//COM petrol	
//IND(tC / yr)	
//IND NG	
//IND petrol	
//ELE(tC / yr)	
//ELE NG	ELE petrol	
//AIR(tC / yr)	
//RAIL(tC / yr)	
//Nonroad(tC / yr)

typedef std::pair<std::string, std::string> FieldField;

void createSectorShape(std::string csvfile, std::string outfile, ShapeCreator::SECTORID sector,std::vector<std::pair<std::string,std::string>> fuelfields)
{
	//ValueField(OGRFieldType otp, std::string destfieldname, std::string firstfieldname, std::string secondfieldname = "")
	ValueField  filterfield(OGRFieldType::OFTInteger, "", "Sector ID");
	filterfield.i = (int)sector;
	std::vector<ValueField> fields;

	ValueField  lonfield(OGRFieldType::OFTReal, "", "New_LON", "longitude");
	ValueField  latfield(OGRFieldType::OFTReal, "", "New_LAT", "latitude");

	fields.push_back(ValueField(OGRFieldType::OFTString, "name", "facility_name"));
	fields.push_back(ValueField(OGRFieldType::OFTString, "facilityid", "facility_id"));
	fields.push_back(ValueField(OGRFieldType::OFTString, "scc", "scc"));
	for (size_t i = 0; i < fuelfields.size(); i++)
	{
		fields.push_back(ValueField(OGRFieldType::OFTReal, fuelfields[i].first, fuelfields[i].second));
	}

	ShapeCreator shpCreator;
	shpCreator.create(csvfile, outfile, fields, lonfield, latfield, filterfield);
}
//"COM (tC/yr)	COM NG	COM petrol	IND (tC/yr)	IND NG	IND petrol	ELE (tC/yr)	ELE NG	ELE petrol	AIR (tC/yr)	RAIL (tC/yr)	Nonroad (tC/yr)"
std::vector<ValueField> getFieldsForSector(ShapeCreator::SECTORID sector)
{
	std::vector<ValueField> fuelfields;
	if (sector == ShapeCreator::IND)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_ng", "IND NG"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_p", "IND petrol"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "IND (tC/yr)"));
	}
	else if (sector == ShapeCreator::COM)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_ng", "COM NG"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_p", "COM petrol"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "COM (tC/yr)"));
	}
	else if (sector == ShapeCreator::ELE)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_ng", "ELE NG"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca_p", "ELE petrol"));
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "ELE (tC/yr)"));
	}
	else if (sector == ShapeCreator::NONROAD)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "Nonroad (tC/yr)"));
	}
	else if (sector == ShapeCreator::AIRPORT)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "AIR (tC/yr)"));
	}
	else if (sector == ShapeCreator::RAILROAD)
	{
		fuelfields.push_back(ValueField(OGRFieldType::OFTReal, "ca", "RAIL (tC/yr)"));
	}
	return fuelfields;
}

std::string getFileNameForSector(ShapeCreator::SECTORID sector)
{
	std::vector<std::pair<std::string, std::string>> fuelfields;
	if (sector == ShapeCreator::IND)
	{
		return "IndPoint";
	}
	else if (sector == ShapeCreator::COM)
	{
		return "ComPoint";
	}
	else if (sector == ShapeCreator::ELE)
	{
		return "ElecProd";
	}
	else if (sector == ShapeCreator::NONROAD)
	{
		return "NonRoadPoint";
	}
	else if (sector == ShapeCreator::AIRPORT)
	{
		return "Airport";
	}
	else if (sector == ShapeCreator::RAILROAD)
	{
		return "RailroadPoint";
	}
	return "";
}
void createShapesForSectors(std::string csvfile, std::string outdir,std::vector<ShapeCreator::SECTORID> sectors)
{
	ShapeCreator shpCreator;
	ValueField  lonfield(OGRFieldType::OFTReal, "", "New_LON", "longitude");
	ValueField  latfield(OGRFieldType::OFTReal, "", "New_LAT", "latitude");

	for (size_t i = 0; i < sectors.size(); i++)
	{
		ShapeCreator::SECTORID sector = sectors[i];
		ValueField  filterfield(OGRFieldType::OFTInteger, "", "Sector ID");
		filterfield.i = (int)sector;
		std::string outfilename = outdir + getFileNameForSector(sector) + ".shp";
		std::vector<ValueField> fuelfields = getFieldsForSector(sector);
		shpCreator.create(csvfile, outfilename, fuelfields, lonfield, latfield, filterfield);
	}
}
//struct SpatialAllocationParams
//{
//	NonPointProcessor::NonPointFuel fuel;
//	int year;
//	int sector;
//	int division;
//	double total;
//	std::string output_field;
//
//};
void calculateNonPointWeight(std::string dir, std::string rscript,std::string sharedCFG)
{
	//std::string sectorname[] = {"ComNonPoint","ResNonPoint","IndNonPoint"};
	NonPointProcessor::NonPointFuel fueltypes[] = { NonPointProcessor::NG,NonPointProcessor::PETROL,NonPointProcessor::COAL };
	std::string fuelfields[] = { "ca_ng", "ca_p","ca_c" };
	std::string sectors[] = { "ComNonPoint","ResNonPoint","IndNonPoint" };
	NonPointProcessor processor;
	for (size_t i = 0; i < 3; i++)
	{
		std::string shapefilename = dir + sectors[i] + ".dbf";
		NonPointProcessor::SpatialAllocationParams ng(NonPointProcessor::NG, 2020, i+1, 9, 1000000, "ca_ng");
		NonPointProcessor::SpatialAllocationParams petrol(NonPointProcessor::PETROL, 2020, i + 1, 9, 1000000, "ca_p");
		NonPointProcessor::SpatialAllocationParams coal(NonPointProcessor::COAL, 2020, i + 1, 9, 1000000, "ca_c");
		std::vector<NonPointProcessor::SpatialAllocationParams> nonpointparams;
		nonpointparams.push_back(ng);
		nonpointparams.push_back(petrol);
		nonpointparams.push_back(coal);
		processor.runRScript(rscript,sharedCFG, shapefilename, nonpointparams);
	}


}

void calNonRoadTotals(std::vector<std::string> dirs,std::string outfile)
{
	std::ofstream ofs;
	ofs.open(outfile.data());
	for (size_t i = 0; i < dirs.size(); i++)
	{
		double sum = ShapeFile::getTotal(dirs[i] + "NonRoadPoint.shp", "ca");
		ofs << dirs[i] + "NonRoadPoint.shp" << "," << sum << "\n";
	}
	ofs.close();
}
void caTotals(std::vector<std::string> dirs, std::string field, std::string shapename, std::string outfile)
{
	std::ofstream ofs;
	ofs.open(outfile.data());
	for (size_t i = 0; i < dirs.size(); i++)
	{
		double sum = ShapeFile::getTotal(dirs[i] + shapename, field);
		ofs << dirs[i] + shapename << "," << sum << "\n";
	}
	ofs.close();
}

void copyField(std::vector<std::string> dirs, std::string oldfield,std::string newfield)
{

	for (size_t i = 0; i < dirs.size(); i++)
	{
		ShapeFile::copyField(dirs[i] + "NonRoad.shp", oldfield, newfield);
	}

}
int main(int argc, char** argv)
{
	OGRRegisterAll();

	std::vector<std::string> LA_DIRS;
	LA_DIRS.push_back("B:/LA_Version2/gridPrep_SHP_master/LA/"); LA_DIRS.push_back("B:/LA_Version2/gridPrep_SHP_master/OR/");
	LA_DIRS.push_back("B:/LA_Version2/gridPrep_SHP_master/RI/"); LA_DIRS.push_back("B:/LA_Version2/gridPrep_SHP_master/SB/");
	LA_DIRS.push_back("B:/LA_Version2/gridPrep_SHP_master/VE/");
	//calNonRoadTotals(LA_DIRS, "nonroadpoint.csv");
	//caTotals(LA_DIRS, "ca", "RailroadPoint.shp","railroadpoint.csv");
	//caTotals(LA_DIRS, "ca", "RailroadPoint.shp", "railroadpoint.csv");
	//copyField(LA_DIRS, "ca11", "ca");
	//return 0;
	//ShapeCreator shpCreator;
	//shpCreator.create("B:/LA_Version2/Processing/LA/Powerplants.txt", "B:/LA_Version2/gridPrep_SHP_master/LA/ElecProd.shp");
	//shpCreator.create("B:/LA_Version2/Processing/OR/Powerplants.txt", "B:/LA_Version2/gridPrep_SHP_master/OR/ElecProd.shp");
	//shpCreator.create("B:/LA_Version2/Processing/RI/Powerplants.txt", "B:/LA_Version2/gridPrep_SHP_master/RI/ElecProd.shp");
	//shpCreator.create("B:/LA_Version2/Processing/SB/Powerplants.txt", "B:/LA_Version2/gridPrep_SHP_master/SB/ElecProd.shp");
	//shpCreator.create("B:/LA_Version2/Processing/VE/Powerplants.txt", "B:/LA_Version2/gridPrep_SHP_master/VE/ElecProd.shp");
	//linkSCC("B:/LA_Version2/gridPrep_SHP_master/LA/ElecProd.shp", "B:/LA_Version2/Processing/NEI_PointSources/LA_basin_ElecProd.shp");
	//linkSCC("B:/LA_Version2/gridPrep_SHP_master/OR/ElecProd.shp", "B:/LA_Version2/Processing/NEI_PointSources/LA_basin_ElecProd.shp");
	//linkSCC("B:/LA_Version2/gridPrep_SHP_master/RI/ElecProd.shp", "B:/LA_Version2/Processing/NEI_PointSources/LA_basin_ElecProd.shp");
	//linkSCC("B:/LA_Version2/gridPrep_SHP_master/SB/ElecProd.shp", "B:/LA_Version2/Processing/NEI_PointSources/LA_basin_ElecProd.shp");
	//linkSCC("B:/LA_Version2/gridPrep_SHP_master/VE/ElecProd.shp", "B:/LA_Version2/Processing/NEI_PointSources/LA_basin_ElecProd.shp");

	//////////NonPointProcessor npProcessor;
	//////////npProcessor.exportBySector("B:/LA_Version2/gridPrep_SHP_master/LA/Parcels_06037_LA.shp", "B:/LA_Version2/gridPrep_SHP_master/LA/");
	//////////npProcessor.exportBySector("B:/LA_Version2/gridPrep_SHP_master/OR/Parcels_06059_OR.shp", "B:/LA_Version2/gridPrep_SHP_master/OR/");
	//////////npProcessor.exportBySector("B:/LA_Version2/gridPrep_SHP_master/RI/Parcels_06065_RI.shp", "B:/LA_Version2/gridPrep_SHP_master/RI/");
	//////////npProcessor.exportBySector("B:/LA_Version2/gridPrep_SHP_master/SB/Parcels_06071_SB.shp", "B:/LA_Version2/gridPrep_SHP_master/SB/");
	//////////npProcessor.exportBySector("B:/LA_Version2/gridPrep_SHP_master/VE/Parcels_06111_VE.shp", "B:/LA_Version2/gridPrep_SHP_master/VE/");
	//createBySector("B:/LA_Version2/Processing/NEI_PointSources/LA_basin_NonElecProd.shp", "B:/LA_Version2/gridPrep_SHP_master/LA/", 6037);
	//createBySector("B:/LA_Version2/Processing/NEI_PointSources/LA_basin_NonElecProd.shp", "B:/LA_Version2/gridPrep_SHP_master/OR/", 6059);
	//createBySector("B:/LA_Version2/Processing/NEI_PointSources/LA_basin_NonElecProd.shp", "B:/LA_Version2/gridPrep_SHP_master/RI/", 6065);
	//createBySector("B:/LA_Version2/Processing/NEI_PointSources/LA_basin_NonElecProd.shp", "B:/LA_Version2/gridPrep_SHP_master/SB/", 6071);
	//createBySector("B:/LA_Version2/Processing/NEI_PointSources/LA_basin_NonElecProd.shp", "B:/LA_Version2/gridPrep_SHP_master/VE/", 6111);

	//std::string nonpoint_RSCRIPT = "B:/LA_Version2/Parcel_Carbon_Allocation/SpatialAllocation.R";
	//std::string sharedCFG = "B:/LA_Version2/Parcel_Carbon_Allocation/shared.csv";
	//calculateNonPointWeight("B:/LA_Version2/gridPrep_SHP_master/LA/", nonpoint_RSCRIPT, sharedCFG);
	//calculateNonPointWeight("B:/LA_Version2/gridPrep_SHP_master/OR/", nonpoint_RSCRIPT, sharedCFG);
	//calculateNonPointWeight("B:/LA_Version2/gridPrep_SHP_master/RI/", nonpoint_RSCRIPT, sharedCFG);
	//calculateNonPointWeight("B:/LA_Version2/gridPrep_SHP_master/SB/", nonpoint_RSCRIPT, sharedCFG);
	//calculateNonPointWeight("B:/LA_Version2/gridPrep_SHP_master/VE/", nonpoint_RSCRIPT, sharedCFG);

	std::vector<ShapeCreator::SECTORID> sectors;
	sectors.push_back(ShapeCreator::IND); sectors.push_back(ShapeCreator::COM); sectors.push_back(ShapeCreator::RAILROAD); sectors.push_back(ShapeCreator::AIRPORT); sectors.push_back(ShapeCreator::NONROAD);
	createShapesForSectors("B:/LA_Version2/Processing/LA/NEI.csv", "B:/LA_Version2/gridPrep_SHP_master/LA/",sectors);
	createShapesForSectors("B:/LA_Version2/Processing/OR/NEI.csv", "B:/LA_Version2/gridPrep_SHP_master/OR/", sectors);
	createShapesForSectors("B:/LA_Version2/Processing/RI/NEI.csv", "B:/LA_Version2/gridPrep_SHP_master/RI/", sectors);
	createShapesForSectors("B:/LA_Version2/Processing/SB/NEI.csv", "B:/LA_Version2/gridPrep_SHP_master/SB/", sectors);
	createShapesForSectors("B:/LA_Version2/Processing/VE/NEI.csv", "B:/LA_Version2/gridPrep_SHP_master/VE/", sectors);

	ScaleByFuel scalebyfuel;
	scalebyfuel.scale("B:/LA_Version2/Processing/LA/Scaling.csv", "B:/LA_Version2/gridPrep_SHP_master/LA/");
	scalebyfuel.scale("B:/LA_Version2/Processing/OR/Scaling.csv", "B:/LA_Version2/gridPrep_SHP_master/OR/");
	scalebyfuel.scale("B:/LA_Version2/Processing/RI/Scaling.csv", "B:/LA_Version2/gridPrep_SHP_master/RI/");
	scalebyfuel.scale("B:/LA_Version2/Processing/SB/Scaling.csv", "B:/LA_Version2/gridPrep_SHP_master/SB/");
	scalebyfuel.scale("B:/LA_Version2/Processing/VE/Scaling.csv", "B:/LA_Version2/gridPrep_SHP_master/VE/");

	gridFolder("B:/LA_Version2/gridPrep_SHP_master/LA/", "B:/LA_Version2/gridPrep_SHP_master/LA/grid/", 500 * 3.28084);
	gridFolder("B:/LA_Version2/gridPrep_SHP_master/OR/", "B:/LA_Version2/gridPrep_SHP_master/OR/grid/", 500 * 3.28084);
	gridFolder("B:/LA_Version2/gridPrep_SHP_master/RI/", "B:/LA_Version2/gridPrep_SHP_master/RI/grid/", 500 * 3.28084);
	gridFolder("B:/LA_Version2/gridPrep_SHP_master/SB/", "B:/LA_Version2/gridPrep_SHP_master/SB/grid/", 500 * 3.28084);
	gridFolder("B:/LA_Version2/gridPrep_SHP_master/VE/", "B:/LA_Version2/gridPrep_SHP_master/VE/grid/", 500 * 3.28084);

	// Preprocessor::gridShapeFile("B:/Shapefiles2Grid/OSM_ONROAD/Baltimore_OnRoad_OSM.shp", "B:/Shapefiles2Grid/OSM_ONROAD/Baltimore_OnRoad_OSM_fishnet.shp", "Z:/Hestia/BALTIMORE/gridPrep_SHP_intersect/fishnet.shp","C11");
    //Preprocessor::gridShapeFile("B:/Shapefiles2Grid/OSM_ONROAD/Marion_Onroad_OSM.shp", "B:/Shapefiles2Grid/OSM_ONROAD/Marion_Onroad_OSM_fishnet.shp", "Z:/Hestia/INDIANAPOLIS/INDIANAPOLIS_NEI2011/gridPrep_SHP_intersect/fishnet.shp","C11");

	//grid.fromFishnetRaster("Z:/Hestia/BALTIMORE/gridPrep_SHP_intersect/fishnet.tif");
	//Preprocessor::intersectWithFishnet

	//Preprocessor::convertPolyline("B:/Shapefiles2Grid/ForJianming/Baltimore_OnRoad_OSM.shp", "B:/Shapefiles2Grid/OSM_ONROAD/Baltimore_OnRoad_OSM.shp");
	//Preprocessor::convertPolyline("B:/Shapefiles2Grid/ForJianming/Marion_Onroad_OSM.shp", "B:/Shapefiles2Grid/OSM_ONROAD/Marion_Onroad_OSM.shp");


	//DbfFile_c dbf("B:/Gridded_Cities/INDIANAPOLIS/0/10m/OnRoad.dbf");
	////dbf.DumpAll("B:/Gridded_Cities/INDIANAPOLIS/0/OnRoad.txt");
	////dbf.DumpAll("B:/Gridded_Cities/INDIANAPOLIS/0/OnRoad.txt");
	//std::vector<const char*> fields2;
	//std::vector<std::string> fields;
	//fields.push_back("Id");
	//fields.push_back("ca11");

	//fields2.push_back("Id");
	//fields2.push_back("ca11");
	////dbf.DumpFields("test.txt",&fields2[0],2);
	//std::vector<std::vector<std::string>> table = dbf.ReadFields(fields);
	//for (size_t i = 0; i < table.size(); i++)
	//{
	//	std::vector<std::string>& row = table[i];
	//	int id = atoi(row[0].data());
	//	double ca = atof(row[1].data());
	//	printf("%d,%d,%f\n", i, id, ca);
	//}
	//return 0;
	//unit is in foot
	//BoundManager::writeBound(BoundManager::readBoundFromShape("B:/Gridded_Cities/SaltLake/NonRoad.shp"),"B:/Gridded_Cities/SaltLake/bound.txt");
	//splitIntoTiles("B:/Gridded_Cities/SaltLake", "B:/Gridded_Cities/SaltLake", BoundManager::readBound("B:/Gridded_Cities/SaltLake/bound.txt"),16000*3.28084);
	//intersectByTiles("B:/Gridded_Cities/SaltLake", "B:/Gridded_Cities/SaltLake", BoundManager::readBound("B:/Gridded_Cities/SaltLake/bound.txt"), 16000 * 3.28084, 32.8084);
	//gridShapeFile("B:/Baltimore/Gridding/Gridding/circle.shp", "B:/Baltimore/Gridding/Gridding/fishnet_hehe.shp", 0.1);
	//BoundManager::writeBound(BoundManager::readBoundFromShape("B:/Gridded_Cities/INDIANAPOLIS/NonRoad.shp"), "B:/Gridded_Cities/INDIANAPOLIS/bound.txt");
	//updateFootprintForDir("B:/Gridded_Cities/INDIANAPOLIS");
	//splitIntoTiles("B:/Gridded_Cities/INDIANAPOLIS", "B:/Gridded_Cities/INDIANAPOLIS", BoundManager::readBound("B:/Gridded_Cities/INDIANAPOLIS/bound.txt"),16000*3.28084);
	//intersectByTiles("B:/Gridded_Cities/INDIANAPOLIS", "B:/Gridded_Cities/INDIANAPOLIS", BoundManager::readBound("B:/Gridded_Cities/INDIANAPOLIS/bound.txt"), 16000 * 3.28084, 32.8084);
	//gridFolder("B:/Gridded_Cities/INDIANAPOLIS", "B:/Gridded_Cities/INDIANAPOLIS/10", 32.8084);
	//updateFootprintForDir("B:/Gridded_Cities/LA/", true);
	//intersectWithPolygonForDir("B:/Gridded_Cities/LA_Boundary_Continental.shp", "B:/Gridded_Cities/LA_Basin/", "B:/Gridded_Cities/LA_County/");
	//OGREnvelope bound = BoundManager::readBound("B:/Baltimore/gridPrep_SHP_master/StatePlane/bound.txt");
	//Grid grid(bound, 200, 1);
	//ShapeFile ref("B:/Baltimore/gridPrep_SHP_master/StatePlane/NonRoad.shp");
	//grid.toShape(&ref,"B:/Baltimore/Hestia_gridding/input/Baltimore/Grids/fishnet.shp");
	//gridFolder("B:/Baltimore/gridPrep_SHP_master/StatePlane/", "B:/Baltimore/gridPrep_SHP_master/StatePlane/200_time/", 200);
	//processFolderForGrids("B:/Baltimore/gridPrep_SHP_master/StatePlane/", "B:/Baltimore/gridPrep_SHP_master/StatePlane/200_time/", "B:/Baltimore/gridPrep_SHP_master/StatePlane/200_time/grids/", 200);
	//upscaleFishnetBySector("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/", 20, "B:/Baltimore/gridPrep_SHP_master/StatePlane/200/");
	//updateFieldAfterIntersectionForDir("B:/Gridded_Cities/LA_County/");
	//updateFootprintForDir("B:/Gridded_Cities/LA_County/trimmed/");

	//BoundManager::writeBound(BoundManager::readBoundFromShape("B:/Gridded_Cities/LA_County/NonRoad.shp"),"B:/Gridded_Cities/LA_County/bound.txt");
	//splitIntoTiles("B:/Gridded_Cities/LA_County", "B:/Gridded_Cities/LA_County", BoundManager::readBound("B:/Gridded_Cities/LA_County/bound.txt"),16000*3.28084);
	//intersectByTiles("B:/Gridded_Cities/LA_County", "B:/Gridded_Cities/LA_County", BoundManager::readBound("B:/Gridded_Cities/LA_County/bound.txt"), 16000 * 3.28084, 32.8084);


	//std::vector<std::string> dirs;
	//dirs.push_back("B:/Gridded_Cities/LA_County/");
	//dirs.push_back("B:/Gridded_Cities/INDIANAPOLIS/");
	//dirs.push_back("B:/Gridded_Cities/SaltLake/");
	//for (size_t i = 0; i < dirs.size(); i++)
	//{
	//
	//	std::string boundfile = dirs[i] + "bound.txt";
	//	mergeTiles(dirs[i], dirs[i] + "merged/", BoundManager::readBound(boundfile), 16000 * 3.28084, "10m");
	//	//std::vector<std::string> subdirs = findChildDirctories(dirs[i], BoundManager::readBound(boundfile), 16000 * 3.28084,"10m");
	//	//for (size_t j = 0; j < subdirs.size(); j++)
	//	//{
	//	//	printf("%s\n", subdirs[j].data());
	//	//	std::stringstream ss;
	//	//	OGREnvelope bound = BoundManager::readBoundFromShape(subdirs[j] + ".shp");
	//	//	updateFieldAfterIntersectionForDir(subdirs[j]);
	//	//	updateFishnet(subdirs[j].data(), bound, 32.8084);
	//	//	
	//	//}
	//}
	//return 0;
	//std::string indir = argv[1];
	//std::string outdir = argv[2];
	//double resol = atof(argv[3]);
	//bool skipNonRoad = false;
	//if (argc > 4)
	//{
	//	if (argv[4] == "true" || atoi(argv[4]) == 1)
	//		skipNonRoad = true;
	//}


	//gridFolder("B:/Baltimore/gridPrep_SHP_master/StatePlane", "B:/Baltimore/gridPrep_SHP_master/StatePlane/500", 500);
	//gridFolder(indir, outdir, resol, skipNonRoad);


	//OGREnvelope bound = BoundManager::readBoundFromShape("B:/Baltimore/gridPrep_SHP_master/StatePlane/NonRoad.shp");
	////splitIntoTiles("B:/Baltimore/gridPrep_SHP_master/StatePlane", "B:/Baltimore/gridPrep_SHP_master/StatePlane/tiles", bound,1000);
	//intersectByTiles("B:/Baltimore/gridPrep_SHP_master/StatePlane", "B:/Baltimore/gridPrep_SHP_master/StatePlane/tiles", bound, 1000,10);

	//sum("B:/Baltimore/gridPrep_SHP_master/WGS84/result");
	//verifyRailRoad();

	//updateFishnet("B:/Baltimore/gridPrep_SHP_master/StatePlane/10");
	//upscaleFishnet("B:/Baltimore/gridPrep_SHP_master/StatePlane", "B:/Baltimore/gridPrep_SHP_master/StatePlane/10",2,"ca11");

	//updateFishnet("B:/Baltimore/gridPrep_SHP_master/StatePlane/10", "B:/Baltimore/gridPrep_SHP_master/StatePlane");


	//upscaleFishnet("B:/Baltimore/gridPrep_SHP_master/StatePlane/10",10,"ca11", 
	//"B:/Baltimore/gridPrep_SHP_master/StatePlane//10/100/fishnet.shp", "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/100/fishnet.tif");
	//BoundManager::writeBound("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/fishnet.shp", "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/bound.txt");
	//BoundManager::writeBound("B:/Baltimore/gridPrep_SHP_master/StatePlane/NonRoad.shp", "B:/Baltimore/gridPrep_SHP_master/StatePlane/bound.txt");
	//BoundManager::writeBound("B:/Baltimore/gridPrep_SHP_master/WGS84/NonRoad.shp", "B:/Baltimore/gridPrep_SHP_master/WGS84/bound.txt");


	//int scales[] = {1,2,4,5,8,10,20,40,50,100};
	//int num = sizeof(scales) / sizeof(int);
	//for (size_t i = 0; i < num; i++)
	//{
	//	int scale = scales[i];
	//	std::stringstream ssShapeFile, ssGridFile;

	//	std::string dir = "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/";
	//	ssShapeFile << dir  << "fishnet/" << scale * 10 << ".shp";
	//	ssGridFile <<  dir  << "fishnet/" << scale * 10 << ".tif";
	//	if (QFileInfo(ssShapeFile.str().data()).exists())
	//		continue;
	//	printf("%s\n", ssShapeFile.str().data());
	//	upscaleFishnet("B:/Baltimore/gridPrep_SHP_master/StatePlane/10", scale, "ca11",
	//		ssShapeFile.str(), ssGridFile.str());
	//}
	//int scales[] = {1};
	//int num = sizeof(scales) / sizeof(int);
	//for (size_t i = 0; i < num; i++)
	//{
	//	int scale = scales[i];
	//	std::stringstream outdir;

	//	std::string dir = "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/";
	//	outdir << dir  << "sectors" << scale * 10 << "/";
	//	upscaleFishnetBySector("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/", scale, outdir.str());
	//	
	//}



	//computeRMSE("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/","B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse.csv");

	/*std::vector<std::string> sectorFiles;
	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/OnRoad.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ResNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/Railroad.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_all.csv");

	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/OnRoad.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ResNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/Railroad.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_all_n.csv", true);

	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/OnRoad.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_onroad.csv");
	
	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ResNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndNonPoint.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_building.csv");




	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/OnRoad.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_onroad_n.csv",true);

	sectorFiles.clear();
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ResNonPoint.shp");
	sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndNonPoint.shp");
	computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/rmse_building_n.csv", true);*/


	//std::vector<std::string> sectorFiles = loadAllSectorFile("B:/Baltimore/gridPrep_SHP_master/StatePlane/10");
	//computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RMSE_ALL.csv");

	//sectorFiles.clear();
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComNonPoint.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ResNonPoint.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndNonPoint.shp");
	//computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RMSE_NonPoint.csv");

	//sectorFiles.clear();
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/OnRoad.shp");
	//computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RMSE_OnRoad.csv");

	//sectorFiles.clear();
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/Railroad.shp");
	//computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RMSE_Railroad.csv");

	//sectorFiles.clear();
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ComPoint.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/IndPoint.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/ElecProd.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RailroadPoint.shp");
	//sectorFiles.push_back("B:/Baltimore/gridPrep_SHP_master/StatePlane/10/Airport.shp");

	//computeRMSE_BySector(sectorFiles, "B:/Baltimore/gridPrep_SHP_master/StatePlane/10/RMSE_Point.csv");


	return 0;



}
