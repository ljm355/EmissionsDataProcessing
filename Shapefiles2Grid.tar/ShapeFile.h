#pragma once
#include "ogrsf_frmts.h"

class ShapeFile
{
public:
	ShapeFile();
	ShapeFile(std::string filename, int update = 0);
	~ShapeFile();
	void close();
	static void move(std::string src, std::string dest);
	void create(std::string filename, OGRSpatialReference* spatialRef = NULL, OGRFeatureDefn *poFDefn = NULL, OGRwkbGeometryType geotype = wkbPolygon);
	static double getTotal(std::string shapefile, std::string fieldname);
	static void copyField(std::string shapefile, std::string oldfield, std::string newfield);
public:
	OGRLayer       *poLayer;
	OGRDataSource   *poDS;
private:
	std::string g_mFileName;
};

