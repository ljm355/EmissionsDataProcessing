#include "ShapeFile.h"
#include "qfileinfo.h"
void ShapeFile::close()
{
	if (poDS)
		OGRDataSource::DestroyDataSource(poDS);
	poDS = NULL;
}
void ShapeFile::create(std::string filename, OGRSpatialReference* spatialRef, OGRFeatureDefn *poFDefn, OGRwkbGeometryType geotype)
{


	g_mFileName = filename;
	if (poDS)
		OGRDataSource::DestroyDataSource(poDS);
	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(
		pszDriverName);

	if (QFileInfo(filename.data()).exists())
	{
		poDriver->DeleteDataSource(filename.data());
		//poDS = OGRSFDriverRegistrar::Open(filename, TRUE);
		//poLayer = poDS->GetLayer(0);
	}

	poDS = poDriver->CreateDataSource(filename.data(), NULL);
	poLayer = poDS->CreateLayer(QFileInfo(filename.data()).baseName().toLocal8Bit().data(), spatialRef, geotype, NULL);

	/*OGRSpatialReference oSRS;
	oSRS.SetWellKnownGeogCS("WGS84");
	poLayer = poDS->CreateLayer(QFileInfo(filename).baseName().toLocal8Bit().data(), &oSRS, tp, NULL);
	OGRSpatialReference* spatialRef = poLayer->GetSpatialRef();*/


	//else
	//{
	if (poFDefn)
	{
		for (int iField = 0; iField < poFDefn->GetFieldCount(); iField++)
		{
			OGRFieldDefn *poFieldDefn = poFDefn->GetFieldDefn(iField);
			poLayer->CreateField(poFieldDefn);
		}
	}
	//}
}

double ShapeFile::getTotal(std::string shapefile, std::string fieldname)
{
	ShapeFile shp(shapefile);
	OGRFeature *poFeature;
	double sum = 0;
	int idx = shp.poLayer->GetLayerDefn()->GetFieldIndex(fieldname.data());
	if (idx < 0)
		return sum;
	
	shp.poLayer->ResetReading();
	while ((poFeature = shp.poLayer->GetNextFeature()) != NULL)
	{
		double value = poFeature->GetFieldAsDouble(idx);
		sum += value;
		OGRFeature::DestroyFeature(poFeature);
	}
	return sum;
}

void ShapeFile::copyField(std::string shapefile, std::string oldfield, std::string newfield)
{
	ShapeFile shp(shapefile,1);
	OGRFeature *poFeature;
	double sum = 0;
	int oldidx = shp.poLayer->GetLayerDefn()->GetFieldIndex(oldfield.data());
	if (oldidx < 0)
		return ;
	int newidx = shp.poLayer->GetLayerDefn()->GetFieldIndex(newfield.data());
	if (newidx < 0)
	{
		OGRFieldDefn* oldfielddef = shp.poLayer->GetLayerDefn()->GetFieldDefn(oldidx);
		OGRFieldDefn newfielddef(newfield.data(),oldfielddef->GetType());
		shp.poLayer->CreateField(&newfielddef);
		newidx = shp.poLayer->GetLayerDefn()->GetFieldIndex(newfield.data());
	}
	OGRFieldType tp = shp.poLayer->GetLayerDefn()->GetFieldDefn(oldidx)->GetType();

	shp.poLayer->ResetReading();
	while ((poFeature = shp.poLayer->GetNextFeature()) != NULL)
	{
		poFeature->SetField(newidx, poFeature->GetRawFieldRef(oldidx));
		shp.poLayer->SetFeature(poFeature);
		OGRFeature::DestroyFeature(poFeature);
	}

}

ShapeFile::ShapeFile()
{
	poDS = NULL;
}

ShapeFile::ShapeFile(std::string filename, int update) {
	g_mFileName = filename;
	poDS = NULL;
	poDS = OGRSFDriverRegistrar::Open(filename.data(), update);
	poLayer = poDS->GetLayer(0);
}

void ShapeFile::move(std::string src, std::string dest)
{
	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(
		pszDriverName);
	poDriver->DeleteDataSource(dest.data());
	OGRDataSource* poDSSrc = OGRSFDriverRegistrar::Open(src.data());
	OGRDataSource* poDSDest = poDriver->CopyDataSource(poDSSrc, dest.data());
	OGRDataSource::DestroyDataSource(poDSSrc);
	OGRDataSource::DestroyDataSource(poDSDest);
	poDriver->DeleteDataSource(src.data());
}
ShapeFile::~ShapeFile()
{
	close();
}
