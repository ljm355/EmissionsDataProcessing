#include "Grid.h"

Grid::Grid(const OGREnvelope& bb, const double& gridcellsize, int expandByCells)
{
	//ShapeFile input(inputfile.data());
	ncols = (bb.MaxX - bb.MinX) / gridcellsize + expandByCells;
	if (gridcellsize * ncols < (bb.MaxX - bb.MinX))
	{
		ncols = ncols + 1;
	}

	nrows = (bb.MaxY - bb.MinY) / gridcellsize + expandByCells;

	//printf("%f,%f\n", bb.MaxX - bb.MinX, bb.MaxY - bb.MinY)
	if (gridcellsize * nrows < (bb.MaxY - bb.MinY))
	{
		nrows = nrows + 1;
	}

	OGREnvelope newbound;
	newbound.MinX = bb.MinX - ((ncols * gridcellsize) - (bb.MaxX - bb.MinX)) * 0.5;
	newbound.MaxX = bb.MaxX + ((ncols * gridcellsize) - (bb.MaxX - bb.MinX)) * 0.5;
	newbound.MinY = bb.MinY - ((nrows * gridcellsize) - (bb.MaxY - bb.MinY)) * 0.5;
	newbound.MaxY = bb.MaxY + ((nrows * gridcellsize) - (bb.MaxY - bb.MinY)) * 0.5;
	bound = newbound;
	_adfGeoTransform[0] = newbound.MinX;
	_adfGeoTransform[1] = gridcellsize;
	_adfGeoTransform[2] = 0;
	_adfGeoTransform[3] = newbound.MaxY;
	_adfGeoTransform[4] = 0;
	_adfGeoTransform[5] = -gridcellsize;
	cells = NULL;
	//reset();
}


void Grid::fromFishnetShape(std::string fishnetfile)
{
	ShapeFile input(fishnetfile.data());
	input.poLayer->GetExtent(&bound);
	OGRFeature *poFeature;
	input.poLayer->ResetReading();
	OGREnvelope cellBB;
	while ((poFeature = input.poLayer->GetNextFeature()) != NULL)
	{

		((OGRPolygon*)poFeature->GetGeometryRef())->getEnvelope(&cellBB);
		OGRFeature::DestroyFeature(poFeature);
		break;
	}
	double gridcellsize = (cellBB.MaxX - cellBB.MinX);
	ncols = (int)((bound.MaxX - bound.MinX) / gridcellsize);
	nrows = (int)((bound.MaxY - bound.MinY) / gridcellsize);

	_adfGeoTransform[0] = bound.MinX;
	_adfGeoTransform[1] = gridcellsize;
	_adfGeoTransform[2] = 0;
	_adfGeoTransform[3] = bound.MaxY;
	_adfGeoTransform[4] = 0;
	_adfGeoTransform[5] = -gridcellsize;
	cells = NULL;
	//reset();
}


void Grid::fromFishnetRaster(std::string fishnetfile,bool load)
{

	cells = NULL;
	const char *pszFormat = "GTiff";
	char **papszOptions = NULL;
	GDALDataset* pDataset = (GDALDataset*)GDALOpen(fishnetfile.data(), GA_ReadOnly);
	pDataset->GetGeoTransform(_adfGeoTransform);
	ncols = pDataset->GetRasterXSize();
	nrows = pDataset->GetRasterYSize();
	//reset();
	//if (load)
	//{
	//	pDataset->GetRasterBand(1)->RasterIO(GF_Read, 0, 0, ncols, nrows, cells, ncols, nrows, GDT_Float64, 0, 0);
	//}
	GDALClose((GDALDatasetH)pDataset);
	bound.MinX = _adfGeoTransform[0];
	bound.MaxY = _adfGeoTransform[3];
	bound.MaxX = _adfGeoTransform[0] + _adfGeoTransform[1] * ncols;
	bound.MinY = _adfGeoTransform[3] + _adfGeoTransform[5] * nrows;
	//reset();
}

Grid::Grid()
{
}


Grid::~Grid()
{
	if (cells)
		delete[] cells;
}
double Grid::calFraction(OGRFeature* fea, const int& footprintIdx)
{

	OGRGeometry* geo = fea->GetGeometryRef();
	OGRwkbGeometryType gtype = geo->getGeometryType();
	if (gtype == wkbLineString || gtype == wkbLineString25D || gtype == wkbMultiLineString)
	{
		double len1 = Utils::calPolylineLength(fea->GetGeometryRef());// *FOOTPRINT_SCALE_FACTOR;
		double len2 = fea->GetFieldAsDouble(footprintIdx);
		return len1 / len2;
	}
	else if (gtype == wkbPolygon || gtype == wkbPolygon25D || gtype == wkbMultiPolygon)
	{
		double area1 = Utils::calPolygonArea(fea->GetGeometryRef());
		double area2 = fea->GetFieldAsDouble(footprintIdx);
		return area1 / area2;
	}

	return 1;
}

int Grid::getNumberOfValidCells()
{
	int count = 0;
	for (size_t i = 0; i < slice; i++)
	{
		double val = cells[i];
		if (val <= 0 || isinf(val) || val != val)
			continue;
		count++;
	}
	return count;
}
void Grid::reset(std::string attributeName)
{
	if (cells)
		delete[] cells;
	cells = new double[ncols*nrows];
	dims.clear();
	dims.push_back(attributeName);
	memset(cells, 0, sizeof(double)*ncols*nrows);
	slice = ncols*nrows;
}
void Grid::reset(std::vector<std::string> dimensions)
{
	dims = dimensions;
	if (cells)
		delete[] cells;
	cells = new double[ncols*nrows*dims.size()];
	memset(cells, 0, sizeof(double)*ncols*nrows*dims.size());
	slice = ncols*nrows;
}

Grid* Grid::createFishnet(const std::string& shapefile, double gridcellsize)
{
	ShapeFile input(shapefile.data());
	OGREnvelope bound;
	input.poLayer->GetExtent(&bound, true);
	Grid* grid = new Grid(bound, gridcellsize);

	return grid;
}

OGRPolygon* Grid::toOGRPolygon(OGRLayer* layer, const OGREnvelope& bb)
{

	OGRPolygon *poPolygon = (OGRPolygon*)OGRGeometryFactory::createGeometry(wkbPolygon);
	OGRLinearRing  *linearRing = (OGRLinearRing  *)OGRGeometryFactory::createGeometry(wkbLinearRing);
	linearRing->addPoint(bb.MinX, bb.MinY);
	linearRing->addPoint(bb.MinX, bb.MaxY);
	linearRing->addPoint(bb.MaxX, bb.MaxY);
	linearRing->addPoint(bb.MaxX, bb.MinY);
	linearRing->addPoint(bb.MinX, bb.MinY);

	poPolygon->addRing(linearRing);//also crashed
	return poPolygon;
}
void Grid::normalizedByArea()
{
	double area = _adfGeoTransform[1] * _adfGeoTransform[1];
	for (size_t i = 0; i < slice; i++)
	{
		cells[i] = cells[i] / area;
	}
}

void Grid::toShape(ShapeFile* copyfrom, const std::string& outputfile, bool writeAttribute)
{

	ShapeFile fishnet;
	fishnet.create(outputfile.data(), copyfrom->poLayer->GetSpatialRef());

	OGRFeatureDefn *poFDefn = fishnet.poLayer->GetLayerDefn();
	double gridcellsize = _adfGeoTransform[1];
	int idIdx = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("Id");
	if (idIdx < 0)
	{
		OGRFieldDefn def("Id", OGRFieldType::OFTInteger);
		fishnet.poLayer->CreateField(&def);
		idIdx = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("Id");
	}
	//int caIndexOutput = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("ca11");
	std::vector<int> fields;
	if (writeAttribute)
	{
		//if (caIndexOutput < 0)
		//{

		//OGRFieldDefn def("ca11", OGRFieldType::OFTReal);
		//fishnet.poLayer->CreateField(&def);
		//caIndexOutput = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("ca11");
		//}

		for (size_t iattribute = 0; iattribute < dims.size(); iattribute++)
		{
			OGRFieldDefn def(dims[iattribute].data(), OGRFieldType::OFTReal);
			fishnet.poLayer->CreateField(&def);
			fields.push_back(fishnet.poLayer->GetLayerDefn()->GetFieldIndex(dims[iattribute].data()));
		}
	}

	int id = 0;
	int slice = nrows * ncols;
	for (size_t i = 0; i < nrows; i++)
	{
		//std::vector<GridCell>& newrow = gridcells[i];
		OGREnvelope tmpBound;
		tmpBound.MaxY = bound.MaxY - gridcellsize * i;
		tmpBound.MinY = bound.MaxY - gridcellsize * (i + 1);
		for (size_t j = 0; j < ncols; j++)
		{

			OGRFeature* poFeaPolygon = OGRFeature::CreateFeature(fishnet.poLayer->GetLayerDefn());

			OGREnvelope bb = tmpBound;
			bb.MinX = bound.MinX + gridcellsize * j;
			bb.MaxX = bound.MinX + gridcellsize * (j + 1);

			poFeaPolygon->SetField(idIdx, id);
			if (writeAttribute)
			{
				//poFeaPolygon->SetField(caIndexOutput, cells[id]);
				for (size_t iattribute = 0; iattribute < dims.size(); iattribute++)
				{
					poFeaPolygon->SetField(fields[iattribute], cells[slice*iattribute + id]);
				}
			}
			OGRPolygon *poPolygon = toOGRPolygon(fishnet.poLayer, bb);
			poFeaPolygon->SetGeometry(poPolygon);


			fishnet.poLayer->CreateFeature(poFeaPolygon);

			OGRFeature::DestroyFeature(poFeaPolygon);
			id++;
		}

	}
}
void Grid::toShape(ShapeFile* copyfrom, const std::string& outputfile, int cellID)
{

	ShapeFile fishnet;
	fishnet.create(outputfile.data(), copyfrom->poLayer->GetSpatialRef());

	OGRFeatureDefn *poFDefn = fishnet.poLayer->GetLayerDefn();
	double gridcellsize = _adfGeoTransform[1];
	int idIdx = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("Id");

	OGRFieldDefn def("Id", OGRFieldType::OFTInteger);
	fishnet.poLayer->CreateField(&def);
	idIdx = fishnet.poLayer->GetLayerDefn()->GetFieldIndex("Id");

	int nrow = cellID / ncols;
	int ncol = cellID % ncols;
	int id = 0;

	OGREnvelope bb;
	bb.MaxY = bound.MaxY - gridcellsize * nrow;
	bb.MinY = bound.MaxY - gridcellsize * (nrow + 1);
	bb.MinX = bound.MinX + gridcellsize * ncol;
	bb.MaxX = bound.MinX + gridcellsize * (ncol + 1);

	OGRFeature* poFeaPolygon = OGRFeature::CreateFeature(fishnet.poLayer->GetLayerDefn());

	poFeaPolygon->SetField(idIdx, id);
	OGRPolygon *poPolygon = toOGRPolygon(fishnet.poLayer, bb);
	poFeaPolygon->SetGeometry(poPolygon);

	fishnet.poLayer->CreateFeature(poFeaPolygon);

	OGRFeature::DestroyFeature(poFeaPolygon);

}
void Grid::toRaster(std::string filename)
{
	GDALAllRegister();
	const char *pszFormat = "GTiff";
	char **papszOptions = NULL;
	GDALDriver *poDriver = GetGDALDriverManager()->GetDriverByName(pszFormat);
	GDALDataset* pDataset = poDriver->Create(filename.data(), ncols, nrows, 1, GDT_Float64, papszOptions);
	pDataset->SetGeoTransform(_adfGeoTransform);
	double* pValue = cells;

	////for (size_t i = 0; i < ncols * nrows; i++)
	////{
	////	float val = _values[i];
	////	if (val < 0 || val > 1000000000)
	////		_values[i] = _nodata;
	////}

	GDALRasterBand *pBand = pDataset->GetRasterBand(1);
	pBand->RasterIO(GF_Write, 0, 0, ncols, nrows, cells, ncols, nrows, GDT_Float64, 0, 0);
	pBand->SetNoDataValue(-9999);

	GDALClose((GDALDatasetH)pDataset);
}
Grid* Grid::upscale(int scale)
{
	Grid* upscaledGrid = new Grid(bound, _adfGeoTransform[1] * scale, 0);
	upscaledGrid->reset();
	int idx = 0;
	for (int nrow = 0; nrow < nrows; nrow++)
	{
		int nrow2 = nrow / scale;
		for (int ncol = 0; ncol < ncols; ncol++)
		{
			int ncol2 = ncol / scale;
			upscaledGrid->cells[ncol2 + nrow2*upscaledGrid->ncols] += cells[idx++];
		}
	}
	return upscaledGrid;
}

void Grid::gatherCells(ShapeFile* input,const char* attributeID)
{

	OGRFeature *poFeature;
	input->poLayer->ResetReading();
	int caIndexOld = input->poLayer->GetLayerDefn()->GetFieldIndex(attributeID);
	int idIndex = input->poLayer->GetLayerDefn()->GetFieldIndex("Id");

	OGRwkbGeometryType gtype = input->poLayer->GetGeomType();
	int footprintIndexOld = -1;
	int footprintIndexNew = -1;
	if (gtype == wkbLineString || gtype == wkbMultiLineString || gtype == wkbLineString25D)
	{
		footprintIndexOld = input->poLayer->GetLayerDefn()->GetFieldIndex("length");
	}
	if (gtype == wkbPolygon || gtype == wkbPolygon25D || gtype == wkbMultiPolygon)
	{
		footprintIndexOld = input->poLayer->GetLayerDefn()->GetFieldIndex("area");
	}
	while ((poFeature = input->poLayer->GetNextFeature()) != NULL)
	{
		

		double fraction = calFraction(poFeature, footprintIndexOld);
		double ca = poFeature->GetFieldAsDouble(caIndexOld);

		if (ca > 0)
		{
			int id = poFeature->GetFieldAsInteger(idIndex);
			cells[id] += ca * fraction;

		}
		OGRFeature::DestroyFeature(poFeature);
	}

}
//void Grid::gatherCells(const std::string& inputfile)
//{
//	ShapeFile input(inputfile.data());
//	gatherCells(&input);
//
//}