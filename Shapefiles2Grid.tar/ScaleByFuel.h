#pragma once
#include "ShapeFile.h"
#include <string>
#include <qstring.h>
#include <vector>
class ScaleByFuel
{
public:
	ScaleByFuel();
	~ScaleByFuel();
	void spatialAllocationTotal(ShapeFile * shp, std::vector<std::string> fuelfieldnames, std::string outputfieldname);
	void spatialAllocationForNonPoint(ShapeFile * shp, int baseyear, std::string weightField, std::string fuel, double total, std::string outputfieldname);
	void spatialAllocation(ShapeFile * shp, std::string weightField, double total, std::string outputfieldname);
	void spatialAllocationElecProd(ShapeFile * shp, std::string weightField, double total, std::string outputfieldname);
	void scale(std::string configfile, std::string dir);
};

