#include "Preprocessor.h"
#include "qfileinfo.h"
#include <fstream>
#include <sstream>
#include <qdir.h>
#include <qstring>
Preprocessor::Preprocessor()
{

}

Preprocessor::~Preprocessor()
{

}



void Preprocessor::intersectWithArcGIS(std::string inputfile1, std::string inputfile2, std::string outputfile)
{
	QFileInfo info(outputfile.data());

	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(pszDriverName);
	poDriver->DeleteDataSource(outputfile.data());
	std::ofstream ofs;
	std::string scriptFile = (info.absoluteDir().absolutePath() + "/" + info.completeBaseName() + ".py").toLocal8Bit().data();
	ofs.open(scriptFile.data());
	std::stringstream script;
	script << "import arcpy" << "\n";
	////script << "fishnetfile = " << "\"" << fishnetfile << "\"" << "\n";
	////script << "inputfile = " << "\"" << inputfile << "\"" << "\n";
	//script << "outputfile = " << "\"" << outputfile << "\"" << "\n";
	script << "arcpy.Intersect_analysis(";
	//script << "fishnetfile" << ";" << "inputfile" << "," << "outputfile" << "," << "\"ALL\"" << "," << "\"\"" << ","  "\"INPUT\")";
	//script << "\"" << fishnetfile << ";" << inputfile << "\"" << "," << "outputfile" << "," << "\"NO_FID\"" << "," << "\"\"" << ","  "\"INPUT\")";
	script << "\"" << inputfile1 << ";" << inputfile2 << "\"" << "," << "\"" << outputfile << "\"" << "," << "\"ALL\"" << "," << "\"\"" << ","  "\"INPUT\")";
	ofs << script.str();
	ofs.close();
	//printf("%s\n", script.str().data());
	system(scriptFile.data());

	QFile::remove(scriptFile.data());
}

void Preprocessor::clipWithArcGIS(std::string fishnetfile, std::string inputfile, std::string outputfile)
{
	QFileInfo info(outputfile.data());

	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(pszDriverName);
	poDriver->DeleteDataSource(outputfile.data());
	std::ofstream ofs;
	std::string scriptFile = (info.absoluteDir().absolutePath() + "/" + info.completeBaseName() + ".py").toLocal8Bit().data();
	ofs.open(scriptFile.data());
	std::stringstream script;
	script << "import arcpy" << "\n";
	script << "arcpy.Intersect_analysis(";
	script << "\"" << fishnetfile << ";" << inputfile << "\"" << "," << "\"" << outputfile << "\"" << "," << "\"\")";
	ofs << script.str();
	ofs.close();
	system(scriptFile.data());
	QFile::remove(scriptFile.data());
}

void Preprocessor::intersectWithFishnet(Grid* grid, const std::string& fishnetfile, const std::string& inputfile, const std::string& outputfile)
{
	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(pszDriverName);
	bool hasFile = false;
	if (QFileInfo(outputfile.data()).exists())
	{
		hasFile = true;
	}
	else
	{
		intersectWithArcGIS(fishnetfile, inputfile, outputfile);
	}

}


std::string Preprocessor::getFootprintFieldName(OGRwkbGeometryType gtype)
{
	if (gtype == wkbLineString || gtype == wkbLineString25D || gtype == wkbMultiLineString)
	{
		return "length";
	}
	else if (gtype == wkbPolygon || gtype == wkbMultiPolygon || gtype == wkbPolygon25D)
	{
		return "area";
	}
	return "";
}


bool Preprocessor::has25D(OGRGeometry* geom)
{
	OGRwkbGeometryType gtype = geom->getGeometryType();
	if (gtype == wkbLineString25D || gtype == wkbMultiLineString25D)
	{
		return true;
	}
	else if (gtype == wkbMultiLineString)
	{
		OGRMultiLineString* multipoly = (OGRMultiLineString*)geom;
		for (size_t i = 0; i < multipoly->getNumGeometries(); i++)
		{

			if (multipoly->getGeometryRef(i)->getGeometryType() == geom->getGeometryType() == wkbLineString25D)
				return true;
		}
	}
}

OGRLineString* Preprocessor::convertOGRLineStringFrom25D(OGRGeometry* geom)
{
	OGRLineString* oldline = (OGRLineString*)geom;
	int len = oldline->getNumPoints();
	OGRLineString *newline = (OGRLineString*)OGRGeometryFactory::createGeometry(wkbLineString);
	for (size_t i = 0; i < len; i++)
	{
		OGRPoint p;
		oldline->getPoint(i, &p);
		newline->addPoint(p.getX(), p.getY());
	}
	return oldline;
}

OGRMultiLineString* Preprocessor::convertOGRMultiLineStringFrom25D(OGRGeometry* geom)
{
	OGRMultiLineString *oldmultipoly = (OGRMultiLineString*)geom;
	OGRMultiLineString *newmultipoly = (OGRMultiLineString*)OGRGeometryFactory::createGeometry(wkbMultiLineString);

	for (size_t i = 0; i < oldmultipoly->getNumGeometries(); i++)
	{
		newmultipoly->addGeometry(convertOGRLineStringFrom25D(oldmultipoly->getGeometryRef(i)));
	}
	return newmultipoly;
}

bool Preprocessor::convertPolylineGeometry(OGRGeometry* geom, OGRGeometry*& newgeom)
{
	//if (!has25D(geom))
	//	return false;
	double len = 0;
	OGRwkbGeometryType gtype = geom->getGeometryType();
	if (geom->getGeometryType() == wkbLineString25D)
	{
		newgeom = convertOGRLineStringFrom25D(geom);
	}
	else if (geom->getGeometryType() == wkbMultiLineString25D)
	{
		newgeom = convertOGRMultiLineStringFrom25D(geom);
	}
	return true;
}

bool Preprocessor::convertPolyline(std::string infile, std::string outfile)
{
	ShapeFile oldShp(infile);
	OGRwkbGeometryType gtype = oldShp.poLayer->GetGeomType();
	if (gtype != wkbLineString25D && gtype != wkbMultiLineString25D)
		return false;
	OGRwkbGeometryType newgtype = wkbLineString;
	if (gtype == wkbMultiLineString25D)
		newgtype = wkbMultiLineString;
	ShapeFile newShp;
	newShp.create(outfile.data(), oldShp.poLayer->GetSpatialRef(), oldShp.poLayer->GetLayerDefn(), newgtype);
	OGRFeature *oldFeature;
	oldShp.poLayer->ResetReading();
	int id = 0;
	while ((oldFeature = oldShp.poLayer->GetNextFeature()) != NULL)
	{

		OGRFeature* newFeature = OGRFeature::CreateFeature(newShp.poLayer->GetLayerDefn());
		for (size_t i = 0; i < oldShp.poLayer->GetLayerDefn()->GetFieldCount(); i++)
		{
			newFeature->SetField(i, oldFeature->GetRawFieldRef(i));
		}
		OGRGeometry* newGeom = NULL;
		if (convertPolylineGeometry(oldFeature->GetGeometryRef(), newGeom)) {
			newFeature->SetGeometry(newGeom);
		}
		else {
			newFeature->SetGeometry(oldFeature->GetGeometryRef());
		}
		newShp.poLayer->CreateFeature(newFeature);
		OGRFeature::DestroyFeature(newFeature);
		OGRFeature::DestroyFeature(oldFeature);
	}
	newShp.close();
	oldShp.close();
	return true;
}

void Preprocessor::gridShapeFile(std::string infile, std::string outfile, std::string fishnetfile,const char* fieldname)
{

	std::string tmpefile = (QFileInfo(outfile.data()).dir().absolutePath() + "/" + QFileInfo(outfile.data()).baseName() + "_2.shp").toLocal8Bit().data();
	std::string outfiletif = (QFileInfo(outfile.data()).dir().absolutePath() + "/" + QFileInfo(outfile.data()).baseName() + ".tif").toLocal8Bit().data();
	Utils::updateFootprint(infile);
	Preprocessor::intersectWithArcGIS(fishnetfile, infile, tmpefile);
	//updateFieldAfterIntersection(tmpefile);
	ShapeFile input(tmpefile);
	Grid fishnet;
	fishnet.fromFishnetShape(fishnetfile);
	fishnet.reset(fieldname);
	fishnet.gatherCells(&input, fieldname);
	fishnet.toShape(&input, outfile, true);
	fishnet.toRaster(outfiletif);
	const char *pszDriverName = "ESRI Shapefile";
	OGRSFDriver *poDriver = OGRSFDriverRegistrar::GetRegistrar()->GetDriverByName(
		pszDriverName);
	poDriver->DeleteDataSource(tmpefile.data());
}