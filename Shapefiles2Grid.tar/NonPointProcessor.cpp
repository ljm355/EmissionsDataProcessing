#include "NonPointProcessor.h"
#include "qdir.h"
#include <fstream>
#include <sstream>
NonPointProcessor::NonPointProcessor()
{
}


NonPointProcessor::~NonPointProcessor()
{

}



//
//fuel	year	sector	total	carbon_conversion	building	division	output_field
//ng	2020	2	204878287	0.014481818	B: / LA_Version2 / gridPrep_SHP_master / LA / ResNonPoint.dbf	9	ca_ng
//petrol	2020	2	40092210	0.019773792	B : / LA_Version2 / gridPrep_SHP_master / LA / ResNonPoint.dbf	9	ca_p
//coal	2020	2	20330	1	B : / LA_Version2 / gridPrep_SHP_master / LA / ResNonPoint.dbf	9	ca_c
void NonPointProcessor::toCSV(std::vector<SpatialAllocationParams> params, std::string shapefilename, std::string outfile)
{
	std::ofstream ofs;
	ofs.open(outfile);
	ofs << "fuel," << "year," << "sector," << "total," << "building," << "division," << "output_field" << "\n";
	std::string fuels[] = {"ng","petrol","coal","elec"};
	for (size_t i = 0; i < params.size(); i++)
	{
		SpatialAllocationParams p = params[i];
		ofs << fuels[p.fuel-1] << "," << p.year << "," << p.sector << "," << p.total << "," << shapefilename << "," << p.division << "," << p.output_field << "\n";
	}
	ofs.close();
}
void NonPointProcessor::runRScript(std::string scriptfile, std::string sharedCFG, std::string shapefilename, std::vector<SpatialAllocationParams> params)
{
	std::string tmpfile = sharedCFG + ".csv";
	toCSV(params, shapefilename,tmpfile);
	std::stringstream ss;
	ss << "RScript " << scriptfile << " " << sharedCFG << " " << tmpfile <<"\n";
	system(ss.str().data());
	QFile::remove(tmpfile.data());
}
//void NonPointProcessor::spatialAllocation(std::string sharedCFG, std::string shapefile, std::string sectorField)
//{
//
//}
void NonPointProcessor::exportBySector(std::string infile, std::string outdir, std::string sectorField)
{

	ShapeFile NonPoint(infile);
	outdir = QDir(outdir.data()).absolutePath().toLocal8Bit().data() + std::string("/");
	ShapeFile ComNonPoint;
	ComNonPoint.create(outdir + "ComNonPoint.shp", NonPoint.poLayer->GetSpatialRef(), NonPoint.poLayer->GetLayerDefn(), NonPoint.poLayer->GetGeomType());

	ShapeFile ResNonPoint;
	ResNonPoint.create(outdir + "ResNonPoint.shp", NonPoint.poLayer->GetSpatialRef(), NonPoint.poLayer->GetLayerDefn(), NonPoint.poLayer->GetGeomType());

	ShapeFile IndNonPoint;
	IndNonPoint.create(outdir + "IndNonPoint.shp", NonPoint.poLayer->GetSpatialRef(), NonPoint.poLayer->GetLayerDefn(), NonPoint.poLayer->GetGeomType());

	OGRLayer* layers[] = { ComNonPoint.poLayer,ResNonPoint.poLayer,IndNonPoint.poLayer };
	//IndPoint.create((dir + "IndPoint.shp").data(), NULL, NULL, OGRwkbGeometryType::wkbPoint);
	//shpBySectors.push_back(ShapeFileBySector(&IndPoint, "IND", 2));
	OGRFeature *poFeature;
	double sum = 0;
	int bcidx = NonPoint.poLayer->GetLayerDefn()->GetFieldIndex(sectorField.data());
	NonPoint.poLayer->ResetReading();
	while ((poFeature = NonPoint.poLayer->GetNextFeature()) != NULL)
	{
		int bc = poFeature->GetFieldAsInteger(bcidx);
		if (bc < 1 || bc > 3)
		{
			continue;
			OGRFeature::DestroyFeature(poFeature);
		}
		OGRLayer* layer = layers[bc - 1];
		layer->CreateFeature(poFeature);
		OGRFeature::DestroyFeature(poFeature);
	}


}

