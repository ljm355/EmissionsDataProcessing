#pragma once
#include "ShapeFile.h"
#include <sstream>
#include <fstream>
class BoundManager
{
public:
	BoundManager();
	~BoundManager();
	static OGREnvelope readBoundFromShape(std::string shapefile)
	{
		ShapeFile input(shapefile);
		OGREnvelope bound;
		input.poLayer->GetExtent(&bound, true);
		return bound;
	}
	static OGREnvelope readBound(std::string filename)
	{
		std::ifstream ifs(filename.data());
		OGREnvelope bound;
		ifs >> bound.MinX >> bound.MaxX >> bound.MinY >> bound.MaxY;
		ifs.close();
		return bound;
	}
	static void writeBound(OGREnvelope bound, std::string outfilename)
	{
		std::ofstream ofs(outfilename.data());
		ofs << bound.MinX << " " << bound.MaxX << " " << bound.MinY << " " << bound.MaxY;
		ofs.close();
	}
	static void writeBound(std::string shapefile, std::string outfilename)
	{
		OGREnvelope bound = readBoundFromShape(shapefile);
		writeBound(bound, outfilename);
	}

};

