#include "BoundManager.h"



BoundManager::BoundManager()
{
}


BoundManager::~BoundManager()
{
}
