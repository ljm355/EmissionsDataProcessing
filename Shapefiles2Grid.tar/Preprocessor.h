#pragma once
#include "Utils.h"
#include "Grid.h"
#include "ShapeFile.h"
class Preprocessor
{
public:
	Preprocessor();
	~Preprocessor();
	static void intersectWithArcGIS(std::string inputfile1, std::string inputfile2, std::string outputfile);
	static void clipWithArcGIS(std::string inputfile1, std::string inputfile2, std::string outputfile);
	static void intersectWithFishnet(Grid* grid, const std::string& fishnetfile, const std::string& inputfile, const std::string& outputfile);
	static bool convertPolyline(std::string infile, std::string outfile);
	static bool convertPolylineGeometry(OGRGeometry* geom, OGRGeometry*& newgeom);
	static OGRMultiLineString* convertOGRMultiLineStringFrom25D(OGRGeometry* geom);
	static OGRLineString* convertOGRLineStringFrom25D(OGRGeometry* geom);
	static bool has25D(OGRGeometry* geom);
	static std::string getFootprintFieldName(OGRwkbGeometryType gtype);
	static void gridShapeFile(std::string infile, std::string outfile, std::string fishnetfile, const char* fieldname = "ca11");
};

