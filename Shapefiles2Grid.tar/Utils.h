#pragma once
#include "ShapeFile.h"
#include <vector>
class Utils
{
public:
	Utils();
	~Utils();
public:
	static double calPolygonArea(OGRGeometry* geom);
	static double calPolylineLength(OGRGeometry* geom);
	static void updateArea(ShapeFile* file);
	static void updateLengh(ShapeFile* file);
	static void updateFootprint(std::string filename);
	static double getDistanceFromLatLonInMeter(double lat1, double lon1, double lat2, double lon2);
	static double getDegreeToMeter(OGRLayer* layer);
	static void updateFootprintForDir(std::string indir, bool force = false);
	static std::vector<std::string> split(const char& delimiter, const std::string& line);
	static std::vector<std::string> splitCSV(const char& delimiter, const std::string& line);
};

